import os

# clas Config:
#     SECRET_KEY = os.environ.get('SECRET